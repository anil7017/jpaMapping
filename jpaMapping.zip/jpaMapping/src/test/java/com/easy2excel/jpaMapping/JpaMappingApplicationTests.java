package com.easy2excel.jpaMapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
